<?php
/* Smarty version 5.4.1, created on 2024-11-08 23:21:15
  from 'file:/Applications/XAMPP/xamppfiles/htdocs/html5up-alpha-kopia/app/../templates/main.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_672e8edb3fc010_44173552',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4ff181e6f13d4a6f093b42748321d5d39dae3b5c' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/html5up-alpha-kopia/app/../templates/main.html',
      1 => 1731104468,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_672e8edb3fc010_44173552 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/Applications/XAMPP/xamppfiles/htdocs/html5up-alpha-kopia/templates';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1><a href="main.html">Aplikacje</a> Sieciowe</h1>
					<nav id="nav">
						<ul>
							<li><a href="main.html">Home</a></li>						
						</ul>
					</nav>
				</header>
				

			<!-- Banner -->
				<section id="banner">
					<h2>Kalkulator Kredytowy</h2>					
				</section>

			<!-- Main -->
				<section id="main" class="container">

					<section class="box special">
						<header class="major">
							<h2>Oblicz swoją ratę szybko i łatwo,
							<br />
							 dopasowując ofertę do swoich potrzeb</h2>
							<p> 
							By zobaczyć najlepsze opcje dla Ciebie.Sprawdź, jaką ratę możesz mieć już dziś!
							<br>Wprowadź kwotę, okres i oprocentowanie,</p>
						</header>
						
					</section>

<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_143390864672e8edb3f79d2_46593224', 'content');
?>
					

					

				</section>

			

			<!-- Footer -->
				<footer id="footer">
					
					<ul class="copyright">
						<li>&copy; Anna Nielepiec</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<?php echo '<script'; ?>
 src="assets/js/jquery.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.dropotron.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.scrollex.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/browser.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/util.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/main.js"><?php echo '</script'; ?>
>

	</body>
</html><?php }
/* {block 'content'} */
class Block_143390864672e8edb3f79d2_46593224 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/Applications/XAMPP/xamppfiles/htdocs/html5up-alpha-kopia/templates';
?>
 <?php
}
}
/* {/block 'content'} */
}
