<?php
/* Smarty version 5.4.1, created on 2024-11-08 23:29:12
  from 'file:/Applications/XAMPP/xamppfiles/htdocs/zad3_szablonowanie/app/../templates/main.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_672e90b8d02944_85444084',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ccbb898c65ee5aa88d90dec4a5eeb5cc60ef7fd3' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/zad3_szablonowanie/app/../templates/main.html',
      1 => 1731104468,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_672e90b8d02944_85444084 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/Applications/XAMPP/xamppfiles/htdocs/zad3_szablonowanie/templates';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Alpha by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1><a href="main.html">Aplikacje</a> Sieciowe</h1>
					<nav id="nav">
						<ul>
							<li><a href="main.html">Home</a></li>						
						</ul>
					</nav>
				</header>
				

			<!-- Banner -->
				<section id="banner">
					<h2>Kalkulator Kredytowy</h2>					
				</section>

			<!-- Main -->
				<section id="main" class="container">

					<section class="box special">
						<header class="major">
							<h2>Oblicz swoją ratę szybko i łatwo,
							<br />
							 dopasowując ofertę do swoich potrzeb</h2>
							<p> 
							By zobaczyć najlepsze opcje dla Ciebie.Sprawdź, jaką ratę możesz mieć już dziś!
							<br>Wprowadź kwotę, okres i oprocentowanie,</p>
						</header>
						
					</section>

<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_1632420515672e90b8d01f15_23396822', 'content');
?>
					

					

				</section>

			

			<!-- Footer -->
				<footer id="footer">
					
					<ul class="copyright">
						<li>&copy; Anna Nielepiec</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<?php echo '<script'; ?>
 src="assets/js/jquery.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.dropotron.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/jquery.scrollex.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/browser.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/util.js"><?php echo '</script'; ?>
>
			<?php echo '<script'; ?>
 src="assets/js/main.js"><?php echo '</script'; ?>
>

	</body>
</html><?php }
/* {block 'content'} */
class Block_1632420515672e90b8d01f15_23396822 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/Applications/XAMPP/xamppfiles/htdocs/zad3_szablonowanie/templates';
?>
 <?php
}
}
/* {/block 'content'} */
}
